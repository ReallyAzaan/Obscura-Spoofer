@echo off
:: Obscura reboot helper - run as Admin after reg add / blocklist / HVCI change
:: Works Win10 19045 / Win11 22621/22631/26100
echo Rebooting in 3s...
timeout /t 3 /nobreak >nul
shutdown /r /t 0 /f
