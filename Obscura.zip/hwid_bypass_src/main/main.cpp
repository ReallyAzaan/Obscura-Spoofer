#include "start/point.h"

inline bool admin = true;

typedef struct _SWAP {
	UNICODE_STRING Name;
	PVOID* Swap;
	PDRIVER_DISPATCH Original;
} SWAP, * PSWAP;

static struct _SWAPS {
	SWAP Buffer[0xFF];
	ULONG Length;
};

_SWAPS SWAPS = { 0 };

NTSTATUS AppendSwap(UNICODE_STRING name, PDRIVER_DISPATCH* swap, NTSTATUS(*hook)(PDEVICE_OBJECT device, PIRP irp), PDRIVER_DISPATCH* original) {

	PSWAP entry = &SWAPS.Buffer[SWAPS.Length++];

	entry->Swap = (PVOID*)swap;
	entry->Original = (PDRIVER_DISPATCH)InterlockedExchangePointer(entry->Swap, hook);
	entry->Name = name;

	*original = entry->Original;


	return STATUS_SUCCESS;
}
NTSTATUS SwapControl(const wchar_t* deviceName, NTSTATUS(*hook)(PDEVICE_OBJECT device, PIRP irp), PDRIVER_DISPATCH* original) {
	UNICODE_STRING devName;
	RtlInitUnicodeString(&devName, deviceName);
	PFILE_OBJECT fileObject = nullptr;
	PDEVICE_OBJECT deviceObject = nullptr;
	NTSTATUS status = IoGetDeviceObjectPointer(&devName, FILE_READ_DATA, &fileObject, &deviceObject);
	if (NT_SUCCESS(status) && deviceObject) {
		PDRIVER_OBJECT driverObject = deviceObject->DriverObject;
		if (driverObject) {
			AppendSwap(devName, &driverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL], hook, original);
		}
		ObDereferenceObject(fileObject);
		return STATUS_SUCCESS;
	}
	return STATUS_UNSUCCESSFUL;
}

// Helper: hook via driver object name directly (avoids double-hooking same device)
static NTSTATUS SwapControlDriver(const wchar_t* driverName, NTSTATUS(*hook)(PDEVICE_OBJECT device, PIRP irp), PDRIVER_DISPATCH* original) {
	UNICODE_STRING drvName;
	RtlInitUnicodeString(&drvName, driverName);
	PDRIVER_OBJECT drvObject = nullptr;
	NTSTATUS status = ObReferenceObjectByName(&drvName, OBJ_CASE_INSENSITIVE, nullptr, 0, *IoDriverObjectType, KernelMode, nullptr, (PVOID*)&drvObject);
	if (NT_SUCCESS(status) && drvObject) {
		UNICODE_STRING nameCopy;
		RtlInitUnicodeString(&nameCopy, driverName);
		AppendSwap(nameCopy, &drvObject->MajorFunction[IRP_MJ_DEVICE_CONTROL], hook, original);
		ObDereferenceObject(drvObject);
		return STATUS_SUCCESS;
	}
	return status;
}

NTSTATUS DriverEntry ( PDRIVER_OBJECT DriverObject , PUNICODE_STRING Driverregistry )
{
	UNREFERENCED_PARAMETER ( DriverObject );
	UNREFERENCED_PARAMETER ( Driverregistry );

	if ( !admin ) {
		startup.run_checks ( );
	}

	///Grab Seed
    UNICODE_STRING RegPath = RTL_CONSTANT_STRING(L"\\Registry\\Machine\\SOFTWARE\\SPOOFER");
	kmdf_settings::hwid_seed = (ULONG)kmdf_communication::ReadRegistry<LONG64>(RegPath, RTL_CONSTANT_STRING(L"P"));
    DbgPrintEx(0, 0, "[+] Seed From Registry : %i\n", kmdf_settings::hwid_seed);
	///Set Seed
	srand(kmdf_settings::hwid_seed);

	// disk.spoof ( ); // UD disk driver - disabled for 19045/22621/26100, use external UD disk

	motherboard.spoof ( );

	//gpu.spoof ( );

	//registry.spoof ( );

	mac.spoof();

	//monitor.spoof_reg ( );

	//monitor.spoof_graphics ( );

	//usb.spoof();

	//tpm.spoof ( );

	//// EFI variable spoofing
	//efi_spoof();

	// ARP - uses completion routine with pattern-scan for Win10+Win11 compat
	// FIX: Hook nsiproxy via device (\\Device\\Nsi). Do NOT double-hook same driver with two different hooks
	// or you will double-allocate IOC_REQUEST and leak/corrupt. Use single hook.
	// Nsi ARP hook DISABLED for Win10 19045 / Win11 22621/22631/26100 stability (0x1E at 970CE/733D/13A5)
	// SwapControl(L"\\Device\\Nsi", NsiDispatchHook, &g_OriginalNsiDispatch); // enable only if HWID needs ARP

	// Hook Tcp for IOCTL_TCP_QUERY_INFORMATION_EX (IFEntry.if_physaddr spoofing)
	// Tcp hook DISABLED for stability (0x1E at 973A5 on 26100) - NIC via ndiswan/GUID is sufficient for popular builds
	// SwapControl(L"\\Device\\Tcp", TcpDispatchHook, &g_OriginalTcpDispatch);

	// Optional: also hook \\Driver\\nsi directly if you need broader coverage without double-hooking same object.
	// This is safe because it references the driver object, not the device object already hooked above.
	// Only enable if your HWID checker queries via \\Driver\\nsi path. It will NOT double-hook if same driver.
	// Uncomment to enable:
	// {
	//     PDRIVER_OBJECT test = nullptr;
	//     UNICODE_STRING nsiDrv = RTL_CONSTANT_STRING(L"\\Driver\\nsiproxy");
	//     if (NT_SUCCESS(ObReferenceObjectByName(&nsiDrv, OBJ_CASE_INSENSITIVE, nullptr, 0, *IoDriverObjectType, KernelMode, nullptr, (PVOID*)&test))) {
	//         bool alreadyHooked = false;
	//         for (ULONG i = 0; i < SWAPS.Length; i++) {
	//             if (SWAPS.Buffer[i].Swap == (PVOID*)&test->MajorFunction[IRP_MJ_DEVICE_CONTROL]) { alreadyHooked = true; break; }
	//         }
	//         ObDereferenceObject(test);
	//         if (!alreadyHooked) {
	//             SwapControlDriver(L"\\Driver\\nsiproxy", NsiDispatchHook2, &g_OriginalNsiDispatch2);
	//         }
	//     }
	// }

	return STATUS_SUCCESS;
}
