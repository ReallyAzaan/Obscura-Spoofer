@echo off
setlocal enabledelayedexpansion
title Obscura Serial Checker - Win10 19045 / Win11 22621/26100
color 0B
echo ========================================================
echo   Obscura HWID Serial Checker
echo   Win10 22H2 19045 ^| Win11 22H2 22621 / 23H2 22631 / 24H2 26100
echo   Run BEFORE and AFTER spoof to verify
echo ========================================================
echo.

net session >nul 2>&1
if %errorlevel% neq 0 (
  echo [!] Not Admin - some queries may fail
  echo     Run as Administrator for full check
  echo.
)

echo [1] DISK -------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_DiskDrive | Select Model,SerialNumber,Size | Format-Table -AutoSize"
echo.
echo   STORAGE DeviceProperty ^(SQP^):
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-PhysicalDisk | Select FriendlyName,SerialNumber,BusType,Size | Format-Table -AutoSize"
echo.
echo   Volume GUIDs:
mountvol 2>nul
echo.

echo [2] MOTHERBOARD / SMBIOS --------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_BaseBoard | Select Manufacturer,Product,SerialNumber,Version | Format-Table -AutoSize"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_BIOS | Select Manufacturer,SMBIOSBIOSVersion,SerialNumber,ReleaseDate | Format-Table -AutoSize"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_ComputerSystem | Select Manufacturer,Model,SystemSKUNumber | Format-Table -AutoSize"
echo   SMBIOS Dump ^(raw^):
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_ComputerSystemProduct | Select IdentifyingNumber,UUID,Name,Vendor | Format-List"
echo.

echo [3] CPU --------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Processor | Select Name,ProcessorId,SerialNumber | Format-Table -AutoSize"
echo.

echo [4] GPU --------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_VideoController | Select Name,DriverVersion,PNPDeviceID | Format-Table -AutoSize"
echo.

echo [5] NIC / MAC --------------------------------------------
getmac /v /fo table 2>nul
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_NetworkAdapter | Where PhysicalAdapter | Select Name,MACAddress,PNPDeviceID | Format-Table -AutoSize"
echo.
echo   ARP Table ^(Nsi - what spoofer hooks^):
arp -a
echo.
echo   TCP IF Table:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetAdapter | Select Name,MacAddress,InterfaceGuid,Status | Format-Table -AutoSize"
echo.

echo [6] RAM --------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_PhysicalMemory | Select Manufacturer,PartNumber,SerialNumber,Capacity | Format-Table -AutoSize"
echo.

echo [7] TPM --------------------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Get-Tpm | Format-List } catch { Write-Host 'TPM not ready' }"
echo.

echo [8] VOLUME SERIAL ----------------------------------------
vol C: 2>nul
vol D: 2>nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_LogicalDisk | Select DeviceID,VolumeSerialNumber,VolumeName | Format-Table -AutoSize"
echo.
echo   MountPoints ^(what disk spoof hooks^):
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Volume | Select DriveLetter,DeviceID,SerialNumber | Format-Table -AutoSize"
echo.

echo [9] EFI / SecureBoot -------------------------------------
powershell -NoProfile -ExecutionPolicy Bypass -Command "try { Confirm-SecureBootUEFI; Write-Host 'SecureBoot: enabled' } catch { Write-Host 'SecureBoot check failed (not admin or not UEFI)' }"
echo.

echo [10] REGISTRY HWID --------------------------------------
echo  -- BaseBoard Registry ^(Enum\SCSI^) --
reg query "HKLM\SYSTEM\CurrentControlSet\Enum\SCSI" /s 2>nul | findstr /i "FriendlyName HardwareID"
echo.
echo  -- Spoofer Registry ^(seed + NDIS^) --
reg query "HKLM\SOFTWARE\SPOOFER" 2>nul
if %errorlevel% neq 0 echo   ^(not set - will use fallback^)
echo.

echo [11] SYSTEM ----------------------------------------------
systeminfo | findstr /i "OS Version"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' | Select CurrentBuild,DisplayVersion,ProductName | Format-List"
echo.

echo ========================================================
echo   SAVE THIS LOG: Right-click -^> Mark -^> Copy
echo   Compare BEFORE vs AFTER spoof
echo   Disk Serial / Model / WWN / Volume GUID should change
echo   MAC last 3 bytes should change, OUI stays
echo   SMBIOS Serial/UUID should change
echo ========================================================
pause
