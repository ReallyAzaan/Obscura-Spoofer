# Obscura Custom KDMapper - works with hwid_bypass_src

Build: kdmapper.sln Release x64
Output: x64\Release\kdmapper_Release.exe (custom, auto-writes SOFTWARE\SPOOFER)

Usage: kdmapper_Release.exe WindowsDriver.sys  [--seed 1234]

- Win10 22H2 19044/19045 and Win11 22621/22631/26100/26200: fallback adapter hook, no PDB needed
- With PDB_OFFSETS: auto-resolves ndis offsets
