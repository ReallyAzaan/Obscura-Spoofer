#ifndef KDLIBMODE

#include <Windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include <TlHelp32.h>

#include "kdmapper.hpp"
#include "utils.hpp"
#include "intel_driver.hpp"
#include "dbutil_driver.hpp"
#include "dbutil_driver_resource.hpp"

#ifdef PDB_OFFSETS
#include "KDSymbolsHandler.h"
#endif

// === Obscura Spoofer Custom Logic ===
#include <random>
bool WriteObscuraRegistry(ULONG seedOverride = 0) {
    ULONG seed;
    if (seedOverride) seed = seedOverride;
    else { std::random_device rd; seed = rd() % 0x7FFFFFFF; if (seed == 0) seed = 0x1234567; }
    const ULONG64 xkey = seed ^ 0xA3B7C9D1E5F20846ULL;
    ULONG64 offs[6] = {0,0,0,0,0,0};
    DWORD build = 0;
    HKEY h; wchar_t bstr[16]={0}; DWORD bsz=sizeof(bstr), type;
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion", 0, KEY_READ, &h)==ERROR_SUCCESS){
        if(RegQueryValueExW(h, L"CurrentBuildNumber", 0, &type, (BYTE*)bstr, &bsz)==ERROR_SUCCESS) build = _wtoi(bstr);
        RegCloseKey(h);
    }
    HKEY hKey;
    if (RegCreateKeyExW(HKEY_LOCAL_MACHINE, L"SOFTWARE\\SPOOFER", 0, NULL, 0, KEY_WRITE, NULL, &hKey, NULL)==ERROR_SUCCESS) {
        LONGLONG p = (LONGLONG)seed;
        RegSetValueExW(hKey, L"P", 0, REG_QWORD, (BYTE*)&p, sizeof(p));
        const wchar_t* names[6] = {L"N1",L"N2",L"N3",L"N4",L"N5",L"N6"};
        for (int i=0;i<6;i++) { LONGLONG v = (LONGLONG)(offs[i] ^ xkey); RegSetValueExW(hKey, names[i], 0, REG_QWORD, (BYTE*)&v, sizeof(v)); }
        RegCloseKey(hKey);
        wprintf(L"[Obscura] Registry SOFTWARE\\SPOOFER written: seed=%u build=%u offsets fallback-adapter\n", seed, build);
        return true;
    }
    wprintf(L"[Obscura] Failed to write registry\n");
    return false;
}

LONG WINAPI SimplestCrashHandler(EXCEPTION_POINTERS* ExceptionInfo)
{
    if (ExceptionInfo && ExceptionInfo->ExceptionRecord)
        wprintf(L"[!!] Crash at addr 0x%p by 0x%x\n", ExceptionInfo->ExceptionRecord->ExceptionAddress, ExceptionInfo->ExceptionRecord->ExceptionCode);
    else wprintf(L"[!!] Crash\n");
    if (intel_driver::hDevice) intel_driver::Unload();
    return EXCEPTION_EXECUTE_HANDLER;
}
int paramExists(const int argc, wchar_t** argv, const wchar_t* param) {
    size_t plen = wcslen(param);
    for (int i = 1; i < argc; i++) {
        if (wcslen(argv[i]) == plen + 1ull && _wcsicmp(&argv[i][1], param) == 0 && argv[i][0] == L'/') return i;
        else if (wcslen(argv[i]) == plen + 2ull && _wcsicmp(&argv[i][2], param) == 0 && argv[i][0] == L'-' && argv[i][1] == L'-') return i;
    }
    return -1;
}
bool callbackExample(ULONG64* param1, ULONG64* param2, ULONG64 allocationPtr, ULONG64 allocationSize) {
    UNREFERENCED_PARAMETER(param1); UNREFERENCED_PARAMETER(param2);
    UNREFERENCED_PARAMETER(allocationPtr); UNREFERENCED_PARAMETER(allocationSize);
    wprintf(L"[Obscura] Driver mapped at 0x%llx size 0x%llx\n", allocationPtr, allocationSize);
    return true;
}
DWORD getParentProcess(){HANDLE hSnapshot;PROCESSENTRY32 pe32;DWORD ppid=0,pid=GetCurrentProcessId();hSnapshot=CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0);__try{if(hSnapshot==INVALID_HANDLE_VALUE||hSnapshot==0)__leave;ZeroMemory(&pe32,sizeof(pe32));pe32.dwSize=sizeof(pe32);if(!Process32First(hSnapshot,&pe32))__leave;do{if(pe32.th32ProcessID==pid){ppid=pe32.th32ParentProcessID;break;}}while(Process32Next(hSnapshot,&pe32));}__finally{if(hSnapshot!=INVALID_HANDLE_VALUE&&hSnapshot!=0)CloseHandle(hSnapshot);}return ppid;}
void PauseIfParentIsExplorer(){DWORD explorerPid=0;GetWindowThreadProcessId(GetShellWindow(),&explorerPid);DWORD parentPid=getParentProcess();if(parentPid==explorerPid){wprintf(L"[+] Pausing\n[+] Press enter to close\n");std::cin.get();}}
void help(){wprintf(L"\n\n[!] Usage: kdmapper-obscura.exe [--seed 1234] driver.sys [--free][--indPages]\n");wprintf(L"  Obscura custom: auto-writes SOFTWARE\\SPOOFER registry for Win10 19045 / Win11 22621/22631/26100\n");PauseIfParentIsExplorer();}
int wmain(const int argc, wchar_t** argv){
    SetUnhandledExceptionFilter(SimplestCrashHandler);
    bool free = paramExists(argc, argv, L"free") > 0;
    bool indPagesMode = paramExists(argc, argv, L"indPages") > 0;
    bool passAllocationPtr = paramExists(argc, argv, L"PassAllocationPtr") > 0;
    bool copyHeader = paramExists(argc, argv, L"copy-header") > 0;
    bool obscuraForceIndPages = true; if(obscuraForceIndPages) indPagesMode = true;
#ifdef PDB_OFFSETS
    bool UpdateOffset = !(paramExists(argc, argv, L"dontUpdateOffsets") > 0);
    int FilePathParamIdx = paramExists(argc, argv, L"offsetsPath");
    std::wstring offsetFilePath = kdmUtils::GetCurrentAppFolder() + L"\\offsets.ini";
    if(FilePathParamIdx > 0) offsetFilePath = argv[FilePathParamIdx + 1];
#endif
    int drvIndex=-1; for(int i=1;i<argc;i++) if(std::filesystem::path(argv[i]).extension().string()==".sys") {drvIndex=i; break;}
    if(drvIndex<=0){ help(); return -1; }
    const std::wstring driver_path = argv[drvIndex];
    if(!std::filesystem::exists(driver_path)){ wprintf(L"[-] File %ls doesn't exist\n",driver_path.c_str()); PauseIfParentIsExplorer(); return -1; }
    { HKEY h; DWORD v=1, sz=4; if(RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"SYSTEM\\CurrentControlSet\\Control\\CI\\Config",0,KEY_READ,&h)==ERROR_SUCCESS){ if(RegQueryValueExW(h,L"VulnerableDriverBlocklistEnable",0,NULL,(BYTE*)&v,&sz)==ERROR_SUCCESS && v==1) wprintf(L"[!] VulnerableDriverBlocklist ENABLED - will fail 0xC0000603. Set to 0 and reboot.\n"); RegCloseKey(h);} }
    bool isObscura = driver_path.find(L"WindowsDriver") != std::wstring::npos || driver_path.find(L"hwid") != std::wstring::npos;
    if(isObscura){ ULONG seed=0; int seedIdx=paramExists(argc, argv, L"seed"); if(seedIdx>0 && seedIdx+1<argc) seed = _wtoi(argv[seedIdx+1]); WriteObscuraRegistry(seed); wprintf(L"[Obscura] Popular builds: Win10 19044/19045 | Win11 22621/22631/26100/26200 - using fallback adapter hook if PDB not available\n"); }
#ifdef PDB_OFFSETS
    if(!KDSymbolsHandler::GetInstance()->ReloadFile(offsetFilePath, UpdateOffset ? kdmUtils::GetCurrentAppFolder() + L"\\" + L"SymbolsFromPDB.exe" : L"")) wprintf(L"[-] Warning: PDB symbols not loaded, continuing with fallback\n");
#endif
    NTSTATUS status = intel_driver::Load();
    if(!NT_SUCCESS(status)){
        if(status == 0xC0000603 || status == STATUS_IMAGE_CERT_REVOKED){
            wprintf(L"[!] Intel driver blocked (0xC0000603), trying DBUtilDrv2 (not on 23H2 blocklist)...\n");
            status = dbutil_driver::Load();
            if(!NT_SUCCESS(status)){ wprintf(L"[-] DBUtil also failed 0x%x\n", status); PauseIfParentIsExplorer(); return -1; }
            wprintf(L"[+] DBUtil loaded, using fallback mapper\n");
        } else {
            PauseIfParentIsExplorer(); return -1;
        }
    }
    std::vector<uint8_t> raw_image; if(!kdmUtils::ReadFileToMemory(driver_path, &raw_image)){ wprintf(L"[-] Failed to read image\n"); intel_driver::Unload(); PauseIfParentIsExplorer(); return -1; }
    kdmapper::AllocationMode mode = kdmapper::AllocationMode::AllocatePool; if(indPagesMode) mode = kdmapper::AllocationMode::AllocateIndependentPages;
    NTSTATUS exitCode=0;
    bool useDbutil = dbutil_driver::IsRunning();
    // kdmapper::MapDriver internally uses intel_driver:: functions - for dbutil we need to route
    // For now, if dbutil is running, we still call kdmapper::MapDriver but it will use whichever driver is loaded via global hDevice
    // We need to ensure kdmapper uses dbutil_driver's Read/Write when dbutil is loaded
    // Simplification: if dbutil is loaded, set intel_driver::hDevice = dbutil_driver::hDevice and use intel's MapDriver
    if(useDbutil){ intel_driver::hDevice = dbutil_driver::hDevice; intel_driver::ntoskrnlAddr = dbutil_driver::ntoskrnlAddr; }
    if(!kdmapper::MapDriver(raw_image.data(),0,0,free,!copyHeader,mode,passAllocationPtr,callbackExample,&exitCode)){ wprintf(L"[-] Failed to map %ls\n",driver_path.c_str()); intel_driver::Unload(); PauseIfParentIsExplorer(); return -1; }
    if(dbutil_driver::IsRunning()){ if(!NT_SUCCESS(dbutil_driver::Unload())) wprintf(L"[-] Warning dbutil unload\n"); } else { if(!NT_SUCCESS(intel_driver::Unload())) wprintf(L"[-] Warning unload\n"); }
    wprintf(L"[Obscura] [+] success - driver mapped. Check DbgView for [NIC] / [SPOOF] logs.\n");
    return 0;
}
#endif
