// main.c - kdmapper-compatible entry. No DRIVER_OBJECT, no registry path.
// The mapper calls us at PASSIVE_LEVEL from its own context; we build the
// identity profile, port the active modules, and return. The driver stays
// resident because our hooks point into this mapped image.
//
// Teardown note (mapped drivers can't "unload"): KdHookRestoreAll() exists;
// a control channel to trigger it is a later step (vmcall/shmem/ioctl against
// a phantom we don't create - registry flag is enough for the lab:
// \Registry\Machine\SOFTWARE\SPOOFER "T"=1 on next boot => modules skip).
// Simplest lab teardown remains: revert the VM snapshot.

#include "core/ntos.h"
#include "core/log.h"
#include "core/hook.h"
#include "core/identity.h"
#include "modules/modules.h"

DRIVER_INITIALIZE HvEntry;

static VOID KdRunModules(VOID)
{
    NTSTATUS st;

    st = FirmwareSpoof();
    KDPRINT("module firmware: 0x%08lx", st);

    st = RegistrySpoof();
    KDPRINT("module registry: 0x%08lx", st);

    // next in README order as they land:
    // st = DiskSpoof();     KDPRINT("module disk: 0x%08lx", st);
    // st = SmbiosSpoof();   KDPRINT("module smbios: 0x%08lx", st);
    // st = NetSpoof();      KDPRINT("module net: 0x%08lx", st);
}

NTSTATUS NTAPI HvEntry(_In_opt_ PVOID Param1, _In_opt_ PVOID Param2)
{
    UNREFERENCED_PARAMETER(Param1);
    UNREFERENCED_PARAMETER(Param2);

    NTSTATUS st = KdIdentityInit();
    if (!NT_SUCCESS(st)) {
        KDPRINT("identity init failed: 0x%08lx - aborting clean", st);
        return st;   // never loaded hooks; box stays stock
    }

    KdRunModules();

    KDPRINT("loaded, hooks=%lu", KdHookCount());
    return STATUS_SUCCESS;
}
