#pragma once
// identity.h - ONE seed -> ONE reproducible "new PC" profile.
// Modules never RNG directly. They ask for their slice of the profile,
// so a re-run with the same seed produces the same machine, and a new
// seed produces a fully consistent different one.

#include "ntos.h"

#define KD_MAX_DISK_SERIAL  24
#define KD_MAX_WWN          16
#define KD_MAX_HOSTNAME     16
#define KD_TPM_EK_BLOB      256

typedef struct _KD_IDENTITY {
    ULONG  Seed;

    // network
    UCHAR  Mac[6];              // locally-administered unicast, sane vendor OUI
    UCHAR  MacOriginal[6];      // best-effort capture before touch (may be zero)

    // identifiers
    GUID   SmbiosUuid;          // Type 1, version-4-style
    CHAR   BoardSerial[17];     // Type 2, model-shaped, NUL-terminated
    CHAR   SystemSerial[17];    // Type 1 serial

    // disk (model-shaped via database seam; filled in by disk module on first
    // query, cached here so every query channel agrees)
    CHAR   DiskSerial[KD_MAX_DISK_SERIAL + 1];
    UCHAR  DiskWwn[KD_MAX_WWN];
    ULONG  VolumeSerial32;      // NTFS boot-sector dword

    // TPM
    UCHAR  EkPub[KD_TPM_EK_BLOB];
    UCHAR  EkMd5[16];
    UCHAR  EkSha1[20];
    UCHAR  EkSha256[32];

    // system identity
    WCHAR  Hostname[KD_MAX_HOSTNAME];   // L"DESKTOP-XXXXXXX"
    UCHAR  Dhcpv6Duid[14];              // DUID-LLT shaped

    BOOLEAN Initialized;
} KD_IDENTITY, *PKD_IDENTITY;

// Reads \\Registry\\Machine\\SOFTWARE\\SPOOFER" "P" (kept for compat with the
// frontend). If absent/zero: generates a seed from system entropy and writes
// it back so the profile survives driver reloads.
NTSTATUS KdIdentityInit(VOID);

// Valid after KdIdentityInit. Read-only by contract; modules consume.
const KD_IDENTITY* KdIdentityProfile(VOID);

// Seeded PRNG for modules that need extra bytes (e.g. EFI vars).
ULONG KdRandom(VOID);
VOID  KdRandomBytes(_Out_writes_(Size) PVOID Buffer, _In_ ULONG Size);

// Set version-4/variant bits on 16 bytes of PRNG output into a GUID shape.
VOID  KdMakeGuidV4(_Out_ GUID* Guid);
