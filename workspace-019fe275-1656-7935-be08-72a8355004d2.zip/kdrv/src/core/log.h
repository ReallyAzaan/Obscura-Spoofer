#pragma once
// log.h - KD-only logging, compiled out of release unless KD_LOG=1.

#include <ntddk.h>

#if DBG || defined(KD_LOG)
#define KDPRINT(fmt, ...) DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "[kd] " fmt "\n", __VA_ARGS__)
#define KDPRINT0(msg)     DbgPrintEx(DPFLTR_IHVDRIVER_ID, DPFLTR_ERROR_LEVEL, "[kd] " msg "\n")
#else
#define KDPRINT(fmt, ...) ((void)0)
#define KDPRINT0(msg)     ((void)0)
#endif
