#include "identity.h"
#include "log.h"

static KD_IDENTITY g_Id;
static ULONG g_RngState;

// Registry helpers ----------------------------------------------------------

static NTSTATUS KdRegReadUlong(_In_ PCWSTR KeyPath, _In_ PCWSTR ValueName, _Out_ ULONG* Value)
{
    UNICODE_STRING usKey, usValue;
    OBJECT_ATTRIBUTES oa;
    HANDLE hKey = NULL;
    NTSTATUS st;

    RtlInitUnicodeString(&usKey, KeyPath);
    RtlInitUnicodeString(&usValue, ValueName);
    InitializeObjectAttributes(&oa, &usKey, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    st = ZwOpenKey(&hKey, KEY_READ, &oa);
    if (!NT_SUCCESS(st)) return st;

    UCHAR buf[sizeof(KEY_VALUE_PARTIAL_INFORMATION) + sizeof(ULONG)];
    ULONG len = 0;
    st = ZwQueryValueKey(hKey, &usValue, KeyValuePartialInformation, buf, sizeof(buf), &len);
    ZwClose(hKey);

    if (NT_SUCCESS(st)) {
        PKEY_VALUE_PARTIAL_INFORMATION info = (PKEY_VALUE_PARTIAL_INFORMATION)buf;
        if (info->Type == REG_DWORD && info->DataLength >= sizeof(ULONG))
            RtlCopyMemory(Value, info->Data, sizeof(ULONG));
        else
            st = STATUS_OBJECT_TYPE_MISMATCH;
    }
    return st;
}

static NTSTATUS KdRegWriteUlong(_In_ PCWSTR KeyPath, _In_ PCWSTR ValueName, _In_ ULONG Value)
{
    UNICODE_STRING usKey, usValue;
    OBJECT_ATTRIBUTES oa;
    HANDLE hKey = NULL;
    ULONG disp = 0;
    NTSTATUS st;

    RtlInitUnicodeString(&usKey, KeyPath);
    RtlInitUnicodeString(&usValue, ValueName);
    InitializeObjectAttributes(&oa, &usKey, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    st = ZwCreateKey(&hKey, KEY_WRITE, &oa, 0, NULL, REG_OPTION_NON_VOLATILE, &disp);
    if (!NT_SUCCESS(st)) return st;
    st = ZwSetValueKey(hKey, &usValue, 0, REG_DWORD, &Value, sizeof(Value));
    ZwClose(hKey);
    return st;
}

// PRNG ----------------------------------------------------------------------

ULONG KdRandom(VOID)
{
    g_RngState = 1664525u * g_RngState + 1013904223u;   // classic LCG
    g_RngState ^= (g_RngState >> 13);                   // cheap decorrelate
    return g_RngState;
}

VOID KdRandomBytes(_Out_writes_(Size) PVOID Buffer, _In_ ULONG Size)
{
    UCHAR* p = (UCHAR*)Buffer;
    for (ULONG i = 0; i < Size; i++)
        p[i] = (UCHAR)(KdRandom() >> 24);
}

VOID KdMakeGuidV4(_Out_ GUID* Guid)
{
    KdRandomBytes(Guid, sizeof(*Guid));
    Guid->Data3 = (USHORT)((Guid->Data3 & 0x0FFF) | 0x4000);  // version 4
    Guid->Data4[0] = (UCHAR)((Guid->Data4[0] & 0x3F) | 0x80); // RFC variant
}

// Profile builders ----------------------------------------------------------

static VOID KdBuildMac(_Out_ UCHAR Mac[6])
{
    // Plausible vendor OUIs (Intel, Realtek, ASMedia, TP-Link, VMware avoided
    // on purpose - a locally-administered OUI must not scream "hypervisor").
    static const UCHAR kOui[][3] = {
        { 0x3C, 0x7C, 0x3F },  // Intel-ish pattern used by consumer boards
        { 0x52, 0x54, 0x1A },  // locally-administered range, unicast
        { 0x1A, 0x2B, 0x3C },  // locally-administered
        { 0x0A, 0xE0, 0x27 },  // locally-administered
    };
    const UCHAR* oui = kOui[KdRandom() % (sizeof(kOui) / sizeof(kOui[0]))];
    Mac[0] = (UCHAR)((oui[0] & 0xFC) | 0x02);  // set LA bit, clear multicast
    Mac[1] = oui[1];
    Mac[2] = oui[2];
    Mac[3] = (UCHAR)(KdRandom() & 0xFF);
    Mac[4] = (UCHAR)(KdRandom() & 0xFF);
    Mac[5] = (UCHAR)(KdRandom() & 0xFF);
}

static VOID KdBuildSerial(_Out_writes_z_(Length) CHAR* Out, _In_ ULONG Length, _In_ BOOLEAN WithDashes)
{
    // Upper-alnum shaped like real board/system serials. Dashes optional at
    // positions 4/9 for vendors that use them.
    static const CHAR kAlpha[] = "0123456789ABCDEFGHJKLMNPQRSTUVWXYZ";
    ULONG j = 0;
    for (ULONG i = 0; i < Length - 1; i++) {
        if (WithDashes && (i == 4 || i == 9)) { Out[i] = '-'; continue; }
        Out[i] = kAlpha[(KdRandom() >> 8) % (sizeof(kAlpha) - 1)];
        j++;
    }
    Out[Length - 1] = '\0';
}

static VOID KdBuildHostname(_Out_ PKD_IDENTITY Id)
{
    static const WCHAR kChars[] = L"0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static const WCHAR kPrefix[] = L"DESKTOP-";
    RtlCopyMemory(Id->Hostname, kPrefix, sizeof(kPrefix) - sizeof(WCHAR));
    for (ULONG i = 0; i < 7; i++)
        Id->Hostname[8 + i] = kChars[(KdRandom() >> 8) % 36];
    Id->Hostname[15] = L'\0';
}

// Init ----------------------------------------------------------------------

NTSTATUS KdIdentityInit(VOID)
{
    NTSTATUS st;
    ULONG seed = 0;

    static const WCHAR kKey[]   = L"\\Registry\\Machine\\SOFTWARE\\SPOOFER";
    static const WCHAR kValue[] = L"P";

    st = KdRegReadUlong(kKey, kValue, &seed);
    if (!NT_SUCCESS(st) || seed == 0) {
        LARGE_INTEGER t;
        ULONG64 tsc = __readmsr(0x10);  // IA32_TSC without including extra headers
        KeQuerySystemTime(&t);
        seed = (ULONG)(t.LowPart ^ t.HighPart ^ (ULONG)(tsc >> 8));
        if (seed == 0) seed = 0xC0FFEE;
        KdRegWriteUlong(kKey, kValue, seed);
        KDPRINT("seed generated: %lu", seed);
    } else {
        KDPRINT("seed from registry: %lu", seed);
    }

    RtlZeroMemory(&g_Id, sizeof(g_Id));
    g_Id.Seed = seed;
    g_RngState = seed;

    KdBuildMac(g_Id.Mac);
    KdMakeGuidV4(&g_Id.SmbiosUuid);

    KdBuildSerial(g_Id.SystemSerial, sizeof(g_Id.SystemSerial), FALSE);
    KdBuildSerial(g_Id.BoardSerial, sizeof(g_Id.BoardSerial), FALSE);

    // Disk serial: 20 chars like ATA firmware; base36, model-db shaping is a
    // disk-module seam (it may overwrite this once it picks a model).
    KdBuildSerial(g_Id.DiskSerial, KD_MAX_DISK_SERIAL + 1, FALSE);
    KdRandomBytes(g_Id.DiskWwn, sizeof(g_Id.DiskWwn));
    g_Id.DiskWwn[0] = (g_Id.DiskWwn[0] & 0x0F) | 0x50;  // NAA 5

    g_Id.VolumeSerial32 = KdRandom() & 0xFFFFFFFF;

    KdRandomBytes(g_Id.EkPub, sizeof(g_Id.EkPub));
    // Ethereum-key-shaped? No - TPM EK RSA-2048 pub area: set plausible header
    // bytes; hashes get computed lazily by the TPM module (crypto not here).
    g_Id.EkPub[0] = 0x00; g_Id.EkPub[1] = 0x01;

    KdBuildHostname(&g_Id);

    // DUID-LLT: type 3, hw type 1, time, then MAC
    g_Id.Dhcpv6Duid[0] = 0x00; g_Id.Dhcpv6Duid[1] = 0x03;
    g_Id.Dhcpv6Duid[2] = 0x00; g_Id.Dhcpv6Duid[3] = 0x01;
    KdRandomBytes(&g_Id.Dhcpv6Duid[4], 4);
    RtlCopyMemory(&g_Id.Dhcpv6Duid[8], g_Id.Mac, 6);

    g_Id.Initialized = TRUE;
    KDPRINT0("identity profile built");
    return STATUS_SUCCESS;
}

const KD_IDENTITY* KdIdentityProfile(VOID)
{
    return g_Id.Initialized ? &g_Id : NULL;
}
