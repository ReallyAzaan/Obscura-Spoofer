#pragma once
// ntos.h - undocumented bits we actually use. Self-contained, no WDK hacks.

#include <ntddk.h>

extern POBJECT_TYPE* IoDriverObjectType;

NTKERNELAPI
NTSTATUS
ObReferenceObjectByName(
    _In_ PUNICODE_STRING ObjectName,
    _In_ ULONG Attributes,
    _In_opt_ PACCESS_STATE AccessState,
    _In_opt_ ACCESS_MASK DesiredAccess,
    _In_ POBJECT_TYPE ObjectType,
    _In_ KPROCESSOR_MODE AccessMode,
    _Inout_opt_ PVOID ParseContext,
    _Out_ PVOID* Object);

NTKERNELAPI
LONG
RtlRandomEx(_Inout_ PULONG Seed);

NTKERNELAPI
NTSTATUS
ExGetFirmwareEnvironmentVariable(
    _In_ PUNICODE_STRING VariableName,
    _In_ LPGUID VendorGuid,
    _Out_writes_bytes_to_opt_(*ValueBufferLength, *ValueBufferLength) PVOID ValueBuffer,
    _Inout_ PULONG ValueBufferLength,
    _Out_opt_ PULONG Attributes);

NTKERNELAPI
NTSTATUS
ExSetFirmwareEnvironmentVariable(
    _In_ PUNICODE_STRING VariableName,
    _In_ LPGUID VendorGuid,
    _In_reads_bytes_opt_(ValueBufferLength) PVOID ValueBuffer,
    _In_ ULONG ValueBufferLength,
    _In_ ULONG Attributes);

#ifndef IRP_MJ_QUERY_VOLUME_INFORMATION
#define IRP_MJ_QUERY_VOLUME_INFORMATION 0x0a
#endif
