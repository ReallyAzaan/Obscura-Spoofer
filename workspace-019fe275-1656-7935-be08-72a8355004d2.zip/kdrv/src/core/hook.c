#include "hook.h"
#include "log.h"

#define KD_MAX_HOOKS 64

typedef struct _KD_HOOK_ENTRY {
    PVOID* Slot;
    PVOID  Original;
    PVOID  Hook;
} KD_HOOK_ENTRY;

static KD_HOOK_ENTRY g_Hooks[KD_MAX_HOOKS];
static volatile LONG g_HookCount = 0;

NTSTATUS KdHookSwapPointer(_In_ PVOID* Slot, _In_ PVOID Hook, _Out_ PVOID* OutOriginal)
{
    if (!Slot || !Hook || !OutOriginal)
        return STATUS_INVALID_PARAMETER;

    LONG idx = InterlockedIncrement(&g_HookCount) - 1;
    if (idx < 0 || idx >= KD_MAX_HOOKS) {
        InterlockedDecrement(&g_HookCount);
        KDPRINT0("hook table full");
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    g_Hooks[idx].Slot = Slot;
    g_Hooks[idx].Hook = Hook;
    g_Hooks[idx].Original = InterlockedExchangePointer(Slot, Hook);
    *OutOriginal = g_Hooks[idx].Original;
    return STATUS_SUCCESS;
}

NTSTATUS
KdHookSwapDispatch(
    _In_ PCWSTR DriverName,
    _In_ ULONG MajorFunction,
    _In_ KD_DISPATCH_FN Hook,
    _Out_ PDRIVER_DISPATCH* OutOriginal)
{
    UNICODE_STRING us;
    PDRIVER_OBJECT drv = NULL;
    NTSTATUS st;

    if (!DriverName || !Hook || !OutOriginal)
        return STATUS_INVALID_PARAMETER;

    RtlInitUnicodeString(&us, DriverName);
    st = ObReferenceObjectByName(&us, OBJ_CASE_INSENSITIVE, NULL, 0,
                                 *IoDriverObjectType, KernelMode, NULL, (PVOID*)&drv);
    if (!NT_SUCCESS(st)) {
        KDPRINT("target %ws not found: 0x%08lx", DriverName, st);
        return st;
    }

    st = KdHookSwapPointer((PVOID*)&drv->MajorFunction[MajorFunction],
                           (PVOID)Hook, (PVOID*)OutOriginal);
    if (NT_SUCCESS(st))
        KDPRINT("hooked %ws mj=%02lx", DriverName, MajorFunction);

    ObDereferenceObject(drv);
    return st;
}

NTSTATUS KdHookRestoreAll(VOID)
{
    LONG count = g_HookCount;
    for (LONG i = count - 1; i >= 0; i--) {
        if (g_Hooks[i].Slot && g_Hooks[i].Hook)
            InterlockedCompareExchangePointer(g_Hooks[i].Slot,
                                              g_Hooks[i].Hook,  // expected current
                                              g_Hooks[i].Original); // hmm: see below
    }
    g_HookCount = 0;
    KDPRINT("restored %ld hooks", count);
    return STATUS_SUCCESS;
}

ULONG KdHookCount(VOID) { return (ULONG)g_HookCount; }

//
// InterlockedCompareExchangePointer above is intentional: we only restore if
// the slot still holds OUR hook. If somebody chained on top of us, we leave
// the chain alone rather than corrupting it (their dispatch now calls into
// our old spot -> our hook still forwards to a valid original).
//

// ---------------------------------------------------------------------------

typedef struct _KD_REWRITE_CTX {
    KD_IRP_REWRITE_FN Fn;
    PVOID             UserContext;
} KD_REWRITE_CTX;

static NTSTATUS NTAPI
KdCompletionTrampoline(
    _In_ PDEVICE_OBJECT Device,
    _In_ PIRP Irp,
    _In_opt_ PVOID Context)
{
    UNREFERENCED_PARAMETER(Device);
    KD_REWRITE_CTX* ctx = (KD_REWRITE_CTX*)Context;
    NTSTATUS rewriteStatus = STATUS_SUCCESS;

    if (ctx) {
        if (NT_SUCCESS(Irp->IoStatus.Status) && ctx->Fn)
            rewriteStatus = ctx->Fn(Irp, ctx->UserContext);
        ExFreePoolWithTag(ctx, 'wRkD');
    }

    // propagate pending flag for stack-based callers
    if (Irp->PendingReturned)
        IoMarkIrpPending(Irp);

    // STATUS_MORE_PROCESSING_REQUIRED would mean we completed the IRP
    // ourselves; rewrites don't, they just patch. Roll on.
    (void)rewriteStatus;
    return STATUS_SUCCESS;
}

VOID
KdPassDownRewrite(_Inout_ PIRP Irp, _In_ KD_IRP_REWRITE_FN Rewrite, _In_opt_ PVOID Context)
{
    KD_REWRITE_CTX* ctx = ExAllocatePool2(POOL_FLAG_NON_PAGED, sizeof(*ctx), 'wRkD');
    if (!ctx) {
        // no memory: forward naked rather than fail the query
        IoSkipCurrentIrpStackLocation(Irp);
        IoCallDriver(IoGetCurrentIrpStackLocation(Irp)->DeviceObject, Irp);
        return;
    }
    ctx->Fn = Rewrite;
    ctx->UserContext = Context;

    IoCopyCurrentIrpStackLocationToNext(Irp);
    IoSetCompletionRoutine(Irp, KdCompletionTrampoline, ctx, TRUE, TRUE, TRUE);

    PDEVICE_OBJECT lower = IoGetCurrentIrpStackLocation(Irp)->DeviceObject;
    IoCallDriver(lower, Irp);
    // note: we ignore IoCallDriver's return intentionally; dispatch returns
    // whatever the lower stack returned by contract of the forwarding pattern.
    // (Hook's job was to arrange the rewrite, not to own the status.)
}
