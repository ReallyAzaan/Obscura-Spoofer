#pragma once
// hook.h - dispatch-swap registry. Every pointer we steal is registered here
// so unload is one call: KdHookRestoreAll(). Completion-rewrite helper included.

#include "ntos.h"

typedef NTSTATUS(NTAPI* KD_DISPATCH_FN)(_In_ PDEVICE_OBJECT Device, _Inout_ PIRP Irp);

// Swap DriverObject->MajorFunction[mj] for \\Driver\\<name> with hook.
// Returns the original via outOriginal. Registers the swap for restore.
NTSTATUS
KdHookSwapDispatch(
    _In_ PCWSTR DriverName,
    _In_ ULONG MajorFunction,
    _In_ KD_DISPATCH_FN Hook,
    _Out_ PDRIVER_DISPATCH* OutOriginal);

// Raw variant: swap an arbitrary function pointer slot, still registered.
NTSTATUS
KdHookSwapPointer(_In_ PVOID* Slot, _In_ PVOID Hook, _Out_ PVOID* OutOriginal);

// Restore everything, last-in-first-out. Safe to call twice.
NTSTATUS
KdHookRestoreAll(VOID);

ULONG
KdHookCount(VOID);

//
// KdPassDownRewrite - the bread-and-butter completion pattern:
// forward the IRP untouched, run Rewrite() at completion, patch the output.
// Rewrite runs at <= DISPATCH_LEVEL with the IRP still owned by us.
//
//   Rewrite(Irp, Context) -> STATUS_SUCCESS keeps the completion rolling.
//
// Context is heap-free by contract: caller owns any buffer lifetime until
// completion; use stack capture structs only if you block on the IRP.
//
typedef NTSTATUS(NTAPI* KD_IRP_REWRITE_FN)(_In_ PIRP Irp, _In_opt_ PVOID Context);

VOID
KdPassDownRewrite(
    _Inout_ PIRP Irp,
    _In_ KD_IRP_REWRITE_FN Rewrite,
    _In_opt_ PVOID Context);
