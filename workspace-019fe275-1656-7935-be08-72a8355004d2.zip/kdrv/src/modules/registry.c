// registry.c - software-side identity: MachineGuid, hostname family,
// DHCPv6 DUID, uuid caches. Registry edits are undetectable as "spoofing"
// per se - the checker just sees different values. Consistency with the
// rest of the profile is what sells it, which is why it all comes from
// KdIdentityProfile().

#include "../core/ntos.h"
#include "../core/identity.h"
#include "../core/log.h"

static NTSTATUS RegWriteSz(_In_ PCWSTR KeyPath, _In_ PCWSTR ValueName, _In_ PCWSTR Data)
{
    UNICODE_STRING usKey, usValue;
    OBJECT_ATTRIBUTES oa;
    HANDLE hKey;
    ULONG disp;
    NTSTATUS st;

    RtlInitUnicodeString(&usKey, KeyPath);
    RtlInitUnicodeString(&usValue, ValueName);
    InitializeObjectAttributes(&oa, &usKey, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    st = ZwCreateKey(&hKey, KEY_WRITE, &oa, 0, NULL, REG_OPTION_NON_VOLATILE, &disp);
    if (!NT_SUCCESS(st)) return st;
    st = ZwSetValueKey(hKey, &usValue, 0, REG_SZ, (PVOID)Data,
                       (ULONG)((wcslen(Data) + 1) * sizeof(WCHAR)));
    ZwClose(hKey);
    return st;
}

static NTSTATUS RegWriteBinary(_In_ PCWSTR KeyPath, _In_ PCWSTR ValueName,
                               _In_reads_bytes_(Size) PVOID Data, _In_ ULONG Size)
{
    UNICODE_STRING usKey, usValue;
    OBJECT_ATTRIBUTES oa;
    HANDLE hKey;
    ULONG disp;
    NTSTATUS st;

    RtlInitUnicodeString(&usKey, KeyPath);
    RtlInitUnicodeString(&usValue, ValueName);
    InitializeObjectAttributes(&oa, &usKey, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

    st = ZwCreateKey(&hKey, KEY_WRITE, &oa, 0, NULL, REG_OPTION_NON_VOLATILE, &disp);
    if (!NT_SUCCESS(st)) return st;
    st = ZwSetValueKey(hKey, &usValue, 0, REG_BINARY, Data, Size);
    ZwClose(hKey);
    return st;
}

static NTSTATUS RegDeleteTree(_In_ PCWSTR KeyPath)
{
    UNICODE_STRING usKey;
    OBJECT_ATTRIBUTES oa;
    HANDLE hKey;
    NTSTATUS st;

    RtlInitUnicodeString(&usKey, KeyPath);
    InitializeObjectAttributes(&oa, &usKey, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);
    st = ZwOpenKey(&hKey, KEY_ALL_ACCESS, &oa);
    if (!NT_SUCCESS(st)) return st; // absent = fine
    st = ZwDeleteKey(hKey);          // fails if subkeys exist; caches usually flat
    ZwClose(hKey);
    return st;
}

NTSTATUS RegistrySpoof(VOID)
{
    const KD_IDENTITY* id = KdIdentityProfile();
    NTSTATUS st;
    ULONG failed = 0;

    if (!id) return STATUS_INVALID_DEVICE_STATE;

    // --- 1. MachineGuid ---
    // Format: string form of a fresh v4 GUID. Cryptography\MachineGuid is
    // THE most-queried software identity value on the system.
    {
        WCHAR guidStr[40];
        UNICODE_STRING us;
        GUID g;
        KdMakeGuidV4(&g);
        us.Buffer = guidStr;
        us.Length = 0; us.MaximumLength = sizeof(guidStr);
        st = RtlStringFromGUID(&g, &us);
        if (NT_SUCCESS(st)) {
            // strip braces RtlStringFromGUID adds
            UNICODE_STRING clean = us;
            clean.Buffer++; clean.Length -= 2 * sizeof(WCHAR);
            st = RegWriteSz(L"\\Registry\\Machine\\SOFTWARE\\Microsoft\\Cryptography",
                            L"MachineGuid", clean.Buffer);
            KDPRINT("reg: MachineGuid -> %ws (0x%08lx)", clean.Buffer, st);
            if (!NT_SUCCESS(st)) failed++;
        } else failed++;
    }

    // --- 2. Hostname family (all copies must agree) ---
    {
        static const struct { PCWSTR Key; PCWSTR Value; } kHost[] = {
            { L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ComputerName", L"ComputerName" },
            { L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Control\\ComputerName\\ActiveComputerName", L"ComputerName" },
            { L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters", L"Hostname" },
            { L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters", L"NV Hostname" },
        };
        for (ULONG i = 0; i < ARRAYSIZE(kHost); i++) {
            st = RegWriteSz(kHost[i].Key, kHost[i].Value, id->Hostname);
            KDPRINT("reg: host[%lu] %ws (0x%08lx)", i, id->Hostname, st);
            if (!NT_SUCCESS(st)) failed++;
        }
    }

    // --- 3. DHCPv6 DUID ---
    st = RegWriteBinary(L"\\Registry\\Machine\\SYSTEM\\CurrentControlSet\\Services\\Tcpip6\\Parameters",
                        L"Dhcpv6DUID", (PVOID)id->Dhcpv6Duid, sizeof(id->Dhcpv6Duid));
    KDPRINT("reg: Dhcpv6DUID (0x%08lx)", st);
    if (!NT_SUCCESS(st)) failed++;

    // --- 4. UUID caches: drop them, let the OS regenerate from spoofed inputs ---
    {
        static const PCWSTR kCaches[] = {
            L"\\Registry\\Machine\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\UuidCache",
            // vendor "uuidsys" style caches vary; drop what exists, tolerate absence
        };
        for (ULONG i = 0; i < ARRAYSIZE(kCaches); i++) {
            st = RegDeleteTree(kCaches[i]);
            KDPRINT("reg: cache drop %ws (0x%08lx)", kCaches[i], st);
            // absence is success here
        }
    }

    KDPRINT("reg: done, failures=%lu", failed);
    return failed == 0 ? STATUS_SUCCESS : STATUS_PARTIAL_COMPLETION;
}
