#pragma once
// modules.h - every feature module exposes init only. No module may bugcheck;
// failure = log + return status, chassis keeps going.

#include "../core/ntos.h"

NTSTATUS FirmwareSpoof(VOID);   // firmware.c  - the 6 NVRAM identity vars
NTSTATUS RegistrySpoof(VOID);   // registry.c  - MachineGuid, hostname, DUID, uuid caches

// ported next, in README order:
// NTSTATUS DiskSpoof(VOID);
// NTSTATUS SmbiosSpoof(VOID);
// NTSTATUS NetSpoof(VOID);
// NTSTATUS TpmSpoof(VOID);
// NTSTATUS MonitorSpoof(VOID);
