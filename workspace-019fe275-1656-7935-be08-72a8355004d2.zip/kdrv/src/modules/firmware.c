// firmware.c - NVRAM identity variables. Direct port of the base's logic,
// framework-adapted: seeded RNG from identity core, module-style failure.
//
// The well-known vendor GUID these six variables live under:
// {eaec226f-c9a3-477a-a826-ddc716cdc0e3}
//
// Tolerance note: not every firmware has every variable. Missing = skip.

#include "../core/ntos.h"
#include "../core/identity.h"
#include "../core/log.h"

#define VAR_ATTR_NON_VOLATILE 0x00000001

static const GUID kVendorGuid =
    { 0xeaec226f, 0xc9a3, 0x477a, { 0xa8, 0x26, 0xdd, 0xc7, 0x16, 0xcd, 0xc0, 0xe3 } };

static BOOLEAN SpoofOne(_In_ PCWSTR Name)
{
    UNICODE_STRING us;
    UCHAR current[0x100] = { 0 };
    UCHAR spoofed[0x100] = { 0 };
    ULONG length = 0xFF;
    ULONG attributes = 0;
    NTSTATUS st;

    RtlInitUnicodeString(&us, Name);

    st = ExGetFirmwareEnvironmentVariable(&us, (LPGUID)&kVendorGuid, current, &length, &attributes);
    if (!NT_SUCCESS(st)) {
        KDPRINT("efi: %ws absent (0x%08lx) - skipped", Name, st);
        return TRUE;  // absent is fine
    }
    if (length == 0 || length > sizeof(current)) {
        KDPRINT("efi: %ws bad length %lu - skipped", Name, length);
        return FALSE;
    }

    KdRandomBytes(spoofed, length);

    // never write an all-equal buffer (some checkers flag degenerate NVRAM)
    BOOLEAN degenerate = TRUE;
    for (ULONG i = 1; i < length; i++)
        if (spoofed[i] != spoofed[0]) { degenerate = FALSE; break; }
    if (degenerate) spoofed[length / 2] ^= 0x5A;

    attributes |= VAR_ATTR_NON_VOLATILE;
    st = ExSetFirmwareEnvironmentVariable(&us, (LPGUID)&kVendorGuid, spoofed, length, attributes);
    if (!NT_SUCCESS(st)) {
        KDPRINT("efi: %ws write failed: 0x%08lx", Name, st);
        return FALSE;
    }

    // read back and require a difference
    UCHAR verify[0x100] = { 0 };
    ULONG vlen = 0xFF;
    st = ExGetFirmwareEnvironmentVariable(&us, (LPGUID)&kVendorGuid, verify, &vlen, NULL);
    if (!NT_SUCCESS(st) || (vlen == length && RtlCompareMemory(verify, current, length) == length)) {
        KDPRINT("efi: %ws verify mismatch", Name);
        return FALSE;
    }

    KDPRINT("efi: %ws randomized (%lu bytes)", Name, length);
    return TRUE;
}

NTSTATUS FirmwareSpoof(VOID)
{
    static const PCWSTR kVars[] = {
        L"UnlockIDCopy",
        L"OfflineUniqueIDRandomSeed",
        L"OfflineUniqueIDRandomSeedCRC",
        L"OfflineUniqueIDEKPub",
        L"OfflineUniqueIDEKPubCRC",
        L"PlatformModuleData",
    };

    ULONG ok = 0, skipped = 0, failed = 0;
    for (ULONG i = 0; i < ARRAYSIZE(kVars); i++) {
        // distinguish "absent" from failure inside SpoofOne via return+status:
        // simplified: TRUE counts OK-or-absent; missing logs say which.
        if (SpoofOne(kVars[i])) ok++; else failed++;
    }
    (void)skipped;

    KDPRINT("efi: done ok=%lu failed=%lu", ok, failed);
    return failed == 0 ? STATUS_SUCCESS : STATUS_PARTIAL_COMPLETION;
}
