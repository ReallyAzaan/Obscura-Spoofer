# kdrv — kernel identity-mutation driver (lab build)

Review of the provided base (`hwsrc/`) and the recode plan. Kernel-only,
loaded via custom kdmapper (objectless entry tolerated), debugged over
KDNET. No hypervisor. No service install. No auth garbage.

## 1. Base review — what we keep, what we throw

| Component | Verdict |
|---|---|
| `disk.h` (~4k lines) | **Keep the logic, port it.** Best part of the base. Hook set: disk / partmgr / mountmgr / storahci / stornvme / spaceport / volmgr + NTFS `IRP_MJ_QUERY_VOLUME_INFORMATION`. Covers StorageQueryProperty (serial/unique-id/WWN), SCSI/ATA/NVMe passthrough serials, media serial, firmware info, mount points, layout. Serial+model databases are the value — preserve them. |
| `nic.h` (NDIS + NSI + TCP) | **Keep + extend.** Miniport walk rewriting current/permanent MAC, NSI ARP hooks (`nsiproxy` + `nsi`, IOCTL `0x12001B`), TCP `0x120003` IFEntry physaddr. Missing: Bluetooth, cached MAC. |
| `base_board.h` (mobo/SMBIOS) | **Keep + extend.** mssmbios registry-data rewrite. Missing: proper PnP-instance serials, needs the raw-table path evaluated (see limits). |
| `efispoof.h` | **Keep almost verbatim.** ExSetFirmwareEnvironmentVariable on the six NVRAM vars. Add: attributes handling + "var missing on this firmware" tolerance (VM firmware may not have all six). |
| `tpm_` (point.h) | **Keep, clean up.** Endorsement reg delete + `\Driver\TPM` dispatch hook rewriting TPM2 `ReadPublic (0x173)` EK. Add: recompute the checker-visible MD5/SHA1/SHA256 of the EK so hashes match the spoofed pubkey. |
| `gpu.h` / `monitor_` | **Enable + port.** WmiMonitorID structures exist; wire the EDID serial/product-code rewrite into the framework. |
| `osp/` `oxygenpdb.lib` | **Drop.** PDB-at-runtime offset resolution needs symbol access = fragile + leaks intent. Replace with pattern scans (already half-present in nic.h) or per-build constants. |
| `startup.run_checks` auth + `bsod(0xDEADDEAD)` | **Deleted, permanently.** License gate from wherever this base came from; also it BSODs the lab box. Gone. |
| `hyperv/visor` | **Dropped** per your decision (kernel-only). Tree stays in `hwsrc/` for later. |
| hook infra (`add_irp_hook`/`AppendSwap`) | **Rebuilt** with registration + full restore on unload logic + per-hook state. |

## 2. Coverage matrix vs your list

| Your signal | Mechanism (kernel-only) | Base has it? | Recode status |
|---|---|---|---|
| StorageQueryProperty | dispatch swap + completion rewrite | ✅ disk.h | port |
| SmartRcvDriveData | same channel (`0x7C088`) | ✅ | port |
| StorageQueryWwn | StorageAdapterProtocolSpecific | ✅ (WWN cache) | port |
| ScsiPassThrough (all variants) | serial rewrite in IDENTIFY words 10–19, byteswapped | ✅ | port |
| AtaPassThrough | same | ✅ | port |
| NvmeProtocolSpecificIoc | Identify Controller SN @bytes 4–23 | ✅ | port |
| SMBIOS Type1 UUID + Type2 serial | mssmbios data + raw-table path | ⚠️ partial | extend |
| ARP/neighbor table | NSI `0x12001B` completion zero/rewrite | ✅ | port |
| NDIS OID MAC / Current+Permanent | miniport walk + OID rewrite | ✅ | port |
| IfBlock @0x466/0x488 | pattern scan instead of PDB | ⚠️ needs conver­sion | recode |
| tdx TCP 0x00120003 | IFEntry if_physaddr rewrite | ✅ | port |
| WMI CurrentAddr/PermanentAddr | serviced by NDIS rewrite | ✅ | port |
| Cached MAC | registry + ARP cache purge | ❌ | new module |
| Bluetooth MAC | `\Driver\BTHUSB` dispatch, `IOCTL_BTH_GET_RADIO_INFO` | ❌ | new module |
| Monitor serial / EDID / ProductCode | `\Driver\monitor` + registry EDID | ⚠️ (gpu.h, disabled) | enable+port |
| UUID cache / uuidsys keys | registry writes | ❌ (`registry/` empty) | new module |
| TPM EK ReadPublic 0x173 + Endorsement + hashes | `\Driver\TPM` hook + reg delete + hash recompute | ⚠️ (auth-coupled, disabled) | enable+port |
| Firmware vars (6) | ExSetFirmwareEnvironmentVariable randomize | ✅ | port |
| Boot GUID (BootIdentifier) | SystemBootEnvironmentInformation path | ❌ | **decide** (see limits) |
| Hostname / DUID / DnsFQDN | registry writes in 5 keys + cache purge | ❌ | new module |

## 3. Known limits of kernel-only (set expectations now)

1. **Raw SMBIOS reads.** A checker that maps `\\.\PhysicalMemory` and parses the
   Type 1/2 tables directly bypasses every OS-level hook. Kernel-only answer:
   the table lives in physical 0xF0000–0x100000; we *can* write the tables in
   place (early-boot values persist in RAM until reboot) — do this as a
   mutation step at load. Hypervisor-grade invisibility for this was the
   EPT-shadow idea; note for later.
2. **Boot GUID.** Forged at kernel boot from the loader block; the clean
   interception is a hook on `NtQuerySystemInformation` — inline-patching
   ntoskrnl `.text` is PatchGuard-visible in short order. Call it after tests:
   either accept partial coverage or mark it as the hypervisor's job later.
3. Everything else on the list is mechanical and safe in kernel mode.

## 4. Recoded architecture

```
kdrv/
├── src/
│   ├── main.c            objectless entry (kdmapper): init all modules, keep-alive
│   ├── core/
│   │   ├── hook.h/.c     dispatch-swap registry, completion helper, restore-all
│   │   ├── identity.h/.c ONE seed -> one profile (MAC with sane OUI, UUIDs,
│   │   │                 disk serials via model db, TPM key blob, hostnames)
│   │   ├── ntos.h        undocumented protos/structs (self-contained)
│   │   └── log.h         DbgPrint gating (off in release)
│   └── modules/
│       ├── disk.*        (port of disk.h handlers -> framework)
│       ├── smbios.*      Type1 UUID + Type2 serial + phys-mem table write
│       ├── net.*         NDIS OIDs + NSI/ARP + TCP + BT + cached MAC
│       ├── monitor.*     EDID chain
│       ├── tpm.*         ReadPublic + endorsement + hash recompute
│       ├── firmware.*    the 6 NVRAM vars
│       ├── registry.*    MachineGuid, UUID caches, hostname/DUID, SQM, etc.
│       └── bootguid.*    (deferred decision)
└── README.md (this file)
```

Framework rules every module obeys:

1. **Register, don't freestyle.** Every swapped pointer is registered in the
   hook table (`hook.h`) so restore is one call. Nothing patches a driver
   object outside the registry.
2. **One identity.** Modules never call RNG directly; they ask
   `identity_profile()` for their slice. One seed → reproducible "new PC".
3. **Fail-safe.** A module failing must not BSOD the box; log + disable.
   The only deliberate bugcheck in this tree is never. Devmode asserts only.
4. Serial output to KD only (release build compiles it out).

## 5. Porting order (build up, verify each against the checker)

1. Chassis (entry, hook registry, identity engine) ← this commit
2. `disk.*` (biggest volume of reused logic; checker reads disk first)
3. `smbios.*`
4. `net.*`
5. `tpm.*`, `firmware.*`, `monitor.*`
6. `registry.*`, cached values
7. Boot GUID decision point.

## 6. Build

EWDK or VS+WDK, WDM (not KMDF — mapped drivers have no driver object).
x64 Release. No imports beyond ntoskrnl/hal. `/NODEFAULTLIB`, entry
`HvEntry` — kdmapper calls it with ignored args.
